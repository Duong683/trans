s = open("challenge.py","r").read()
while True:
	c = raw_input()
	ss = ""
	for i in range(len(s)):
		if(s[i] == c):
			ss += ' '
		else:
			ss += s[i]
	print ss
	s = ss	
