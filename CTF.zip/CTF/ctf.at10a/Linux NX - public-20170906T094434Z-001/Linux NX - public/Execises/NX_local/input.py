#!/usr/bin/python

from pwn import *
import sys

while True:
	mStr = raw_input()
	sys.stdout.write(mStr)
	sys.stdout.flush()
	if mStr == 'exit\n': exit(0)