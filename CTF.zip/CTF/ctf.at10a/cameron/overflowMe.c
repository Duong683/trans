int __cdecl main(int argc, const char **argv, const char **envp)
{
  char v4; // [sp+1Bh] [bp-65h]@4
  size_t _7F; // [sp+7Fbh] [bp-1h]@1

  setvbuf(stdin, 0, 2, 0);
  setvbuf(stdout, 0, 2, 0);
  puts("Buffer overflow");
  puts("Give me the size:");
  __isoc99_scanf("%hhd", &_7F);		//short integer
  if ( (char)_7F > 100 )
  {
    puts("You can't exploit my program!");
    exit(1);
  }
  puts("Give me the buffer:");
  read(0, &v4, (unsigned __int8)_7F);
  puts("Your input:");
  puts(&v4);
  return 0;
}
