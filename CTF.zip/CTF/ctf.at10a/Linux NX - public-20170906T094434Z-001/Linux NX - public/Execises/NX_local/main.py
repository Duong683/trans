#!/usr/bin/python

import re

mStr = open('gadgets_libc_Ubuntu32.txt', 'rb').read()

print(mStr[1000:1100])

ret = re.findall(r'xor eax, 0x[0-9A-F]{1,8} ; ret', mStr)

print(ret)