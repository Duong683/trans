#include <sys/mman.h>
#include <errno.h>
#include <stdio.h>

int main()
{
	char buf[10];
	int address, size, prot;
	printf("PROT_READ: 0x%x\n", PROT_READ);
	printf("PROT_WRITE: 0x%x\n", PROT_WRITE);
	printf("PROT_EXEC: 0x%x\n", PROT_EXEC);
	printf("PROT_NONE: 0x%x\n", PROT_NONE);
	printf("Address of buf: %p\n", buf);
	printf("Input your address: ");
	scanf("%x", &address);
	printf("Input your size: ");
	scanf("%d", &size);
	printf("Input your prot: ");
	scanf("%d", &prot);
	int ret = mprotect((void*)address, size, prot);
	printf("Return value: %d\n", ret);
	printf("Errno: %d\n", errno);
	printf("EINVAL: %d\n", EINVAL);
	return 0;
}