#include <stdio.h>

// gcc -fno-stack-protector printHello.c -o printHello # => printHello_nx
// gcc -z execstack -fno-stack-protector printHello.c -o printHello # => printHello_not_nx

int main() {
    char buf[20];
	puts("Input your name:");
    gets(buf);
    printf("Hello %s\n", buf);
    return 0;
}
