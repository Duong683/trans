#include <stdio.h>
#include <string.h>

#include <iostream>
using namespace std;
unsigned long hashcode = 0x21DD09EC;
unsigned long check_password(const char* p){
	int* ip = (int*)p;
	int i;
	int res=0;
	for(i=0; i<5; i++){
		printf("%d\n", ip[i]);
		printf("%d\n", res);
		res += ip[i];
	}
	return res;
}

unsigned long get_pw(const char* p){
	int* pw = (int*)p;
	int i;
	int res = hashcode;
	cout << "Please enter an integer value: ";
	//printf("%d\n", res);
	for(i=4; i>=1; i--){
		//printf("%d\n", pw[i]);
		res -= pw[i];
		//printf("%d\n", res);
	}
	
	return res;
}

int main(int argc, char* argv[]){
	
	get_pw( argv[1] );
	
	return 0;
}

