#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
	
	size_t a;
	scanf ("%hhd",a);
	char temp = (char)a;
	printf("%c", &temp);
	//printf("overflow me : ");
	//gets(overflowme);	// smash me!
	
	return 0;
}
