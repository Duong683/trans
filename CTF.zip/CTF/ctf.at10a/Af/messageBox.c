int __cdecl main(int argc, const char **argv, const char **envp)
{
  unsigned int v3; // eax@1
  float v4; // ST1C_4@1
  int result; // eax@2
  int v6; // [sp+28h] [bp-28h]@1
  float v7; // [sp+48h] [bp-8h]@1
  float v8; // [sp+4Ch] [bp-4h]@1

  setvbuf(stdout, 0, 2, 0);
  v3 = time(0);
  srand(v3);
  v4 = (long double)rand() * 1337.0;
  v7 = v4;
  puts("Welcome, what is your name?");
  memset(&v6, 0, 0x20u);
  __isoc99_scanf("%s", &v6);
  printf("Enter your key: ");
  __isoc99_scanf("%f%*c", &v8);
  if ( v7 == v8 )
  {
    puts("Leave your message:");
    fgets(message, 1024, _bss_start);
    printf("Got:%s\n", message);
    result = 0;
  }
  else
  {
    puts("You entered a wrong key. Bye, bye.");
    result = 1;
  }
  return result;
}
